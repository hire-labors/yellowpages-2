﻿namespace YellowPages
{
    partial class AddForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtFirst = new System.Windows.Forms.TextBox();
            this.txtSurname = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.mcaBDay = new System.Windows.Forms.MonthCalendar();
            this.SuspendLayout();
            // 
            // txtFirst
            // 
            this.txtFirst.Location = new System.Drawing.Point(13, 48);
            this.txtFirst.Name = "txtFirst";
            this.txtFirst.Size = new System.Drawing.Size(166, 20);
            this.txtFirst.TabIndex = 1;
            // 
            // txtSurname
            // 
            this.txtSurname.Location = new System.Drawing.Point(221, 48);
            this.txtSurname.Name = "txtSurname";
            this.txtSurname.Size = new System.Drawing.Size(166, 20);
            this.txtSurname.TabIndex = 2;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(12, 96);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(374, 20);
            this.textBox3.TabIndex = 3;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(12, 146);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(87, 20);
            this.textBox4.TabIndex = 4;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(126, 146);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(87, 20);
            this.textBox5.TabIndex = 5;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(253, 146);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(87, 20);
            this.textBox6.TabIndex = 6;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "7th-11th Kilometer",
            "Abdovista",
            "American College",
            "Banishora",
            "Belite Brezi",
            "Benkovski",
            "Bororvo",
            "Boyana",
            "Busmantsi",
            "Buxton",
            "Center",
            "Dianabad",
            "Dimitar Milenkov",
            "Doctor\'s Monument",
            "Dragalevtsi",
            "Druzhba 1",
            "Druzhba 2",
            "Durvenistsa",
            "Fakulteta",
            "Geo Milev",
            "Gorna Banya",
            "Gorubliane",
            "Gotse Delchev",
            "Gradina",
            "Hadji Dimitar",
            "Hipodruma",
            "Hristo Botev",
            "Ilinden",
            "Iliyantsi",
            "Ivan Vazov",
            "Izgrev",
            "Iztok",
            "Karpuzitsa",
            "Khladilnik",
            "Krasna Polyana 1",
            "Krasna Polyana 2",
            "Krasna Polyana 3",
            "Krasna Selo",
            "Kremikovtzi",
            "Kriva River",
            "Krustova vada",
            "Lagera",
            "Levski",
            "Levski B",
            "Levski G",
            "Lozenets",
            "Lyulin 1",
            "Lyulin 10",
            "Lyulin 2",
            "Lyulin 3",
            "Lyulin 4",
            "Lyulin 5",
            "Lyulin 6",
            "Lyulin 7",
            "Lyulin 8",
            "Lyulin 9",
            "Lyulin Center",
            "M-T Batareyata",
            "M-T Cinema Center",
            "M-T Detski Grad",
            "M-T Gurdova Glava",
            "M-T Marla Koria",
            "Malashevsti",
            "Malinova Dolina",
            "Manastiriski Livadi",
            "Medical Academy",
            "Mladost 1",
            "Mladost 1A",
            "Mladost 2",
            "Mladost 3",
            "Mladost 4",
            "Moderno Predgradie",
            "Musagenista",
            "Nadezhda 1",
            "Nadezhda 2",
            "Nadezhda 3",
            "Nadezhda 4",
            "NPZ Hadzhi Dimitar",
            "NPZ Iskar",
            "NPZ Iztok",
            "NZZ Sredets",
            "Obelya 1",
            "Obelya 2",
            "Oborishte",
            "Orlandovtsi",
            "Ovcha Kupel 1",
            "Ovcha Kupel 2",
            "Pavlovo",
            "Philiportsi",
            "Poduyane",
            "Poligona",
            "PZ Hladilnika",
            "PZ Illiyantsi",
            "Razsadnika",
            "Reduta",
            "Serdika",
            "Simeonovo",
            "Skladovi Zhilishta",
            "Slatina",
            "Slavia",
            "Sofia Airport",
            "SPS Slatina",
            "SPZ Moderno Predgradie",
            "Strelbishte",
            "Studentski Grad",
            "Sugar Factory",
            "Suhata Reka",
            "Suhodol",
            "Sveta Troista",
            "Svoboda",
            "Tolstoy",
            "Triugulnika",
            "v.z. Bjoyana",
            "v.z. Bunkera",
            "v.z. Dragalevtsi lift station",
            "v.z. Gaboro-Azata",
            "v.z. Kiliite",
            "v.z. Kinocenter",
            "v.z. Kinocenter 3 part",
            "v.z. Malinova Dolina",
            "v.z. Malinova Dolina-Gerena",
            "v.z. Mogilata",
            "v.z. Simeonovo-Draglevtsi",
            "v.z. Vrana-German",
            "v.z. Vrana-Lozen",
            "Vidnite",
            "Vitosha",
            "Voluyak",
            "Vrabnista 1",
            "Vrabnista 2",
            "Vrazhdebena",
            "Yavorov",
            "Zapaden Park",
            "zh.gr. Yuzhen Park",
            "zh.gr. Zooparka",
            "Zona B- 18",
            "Zona B- 19",
            "Zona B- 5",
            "Zona B- 5-3"});
            this.comboBox1.Location = new System.Drawing.Point(12, 194);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(166, 21);
            this.comboBox1.Sorted = true;
            this.comboBox1.TabIndex = 7;
            this.comboBox1.Text = "--Select the area you live in--";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "First Name: ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(218, 29);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Surname: ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 80);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Street: ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 130);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(69, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Block or No: ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(123, 130);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(36, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "Floor: ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(250, 130);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(61, 13);
            this.label6.TabIndex = 0;
            this.label6.Text = "Apart No. : ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 178);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(51, 13);
            this.label7.TabIndex = 0;
            this.label7.Text = "Quarter : ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(13, 227);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(44, 13);
            this.label8.TabIndex = 0;
            this.label8.Text = "Phone: ";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(410, 80);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(87, 13);
            this.label9.TabIndex = 0;
            this.label9.Text = "Select Birthday : ";
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(221, 243);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(166, 20);
            this.textBox7.TabIndex = 9;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(12, 243);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(166, 20);
            this.textBox1.TabIndex = 8;
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(221, 291);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 10;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(116, 291);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 23);
            this.btnClear.TabIndex = 10;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(16, 291);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 10;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            // 
            // mcaBDay
            // 
            this.mcaBDay.Location = new System.Drawing.Point(402, 101);
            this.mcaBDay.MaxSelectionCount = 1;
            this.mcaBDay.Name = "mcaBDay";
            this.mcaBDay.TabIndex = 11;
            // 
            // AddForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(654, 336);
            this.Controls.Add(this.mcaBDay);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.txtSurname);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.txtFirst);
            this.Name = "AddForm";
            this.Text = "Add Form";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtFirst;
        private System.Windows.Forms.TextBox txtSurname;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.MonthCalendar mcaBDay;
    }
}

